-- funnel3.lua - SIMION Lua workbench user program for ion funnel.
--
-- This is similar to funnel2.lua but uses additional electrode
-- solution arrays to allow adjustable variables (_RF_amplitude,
-- _DC_offset_1, _DC_offset_16, and _DC_offset_17) to be adjusted
-- during the Fly'm (without editing the .pa+ file and re-refining
-- the array).
--
-- D.Manura, 2009-08, based on funnel2.lua.

simion.workbench_program()

--import standard HS1 collision model from this directory.
simion.import("collision_hs1.lua")

local OPT = simion.import 'geneticlib.lua'


adjustable DC_min = 210
adjustable DC_max = 330
adjustable RF_min = 75  --�ſ�
adjustable RF_max = 110
adjustable d_min  = 1.00  --�缫��϶
adjustable d_max  = 1.40
adjustable r_min  = 1.5     --�����ھ�
adjustable r_max  = 2.3



adjustable population_size = 350   --n
adjustable max_iterations = 100  --m            n+2*m
adjustable mutation_probability = 1
adjustable metric_goal = 0  --�����λ�ɱ��˾�����������ns

-- adjustable during flight

adjustable _temperature_k       = 273.0      -- Background gas temperature (K)                                             --   [OVERRIDE HS1]
adjustable _sigma_m2            = 2.27E-18   -- Collision-cross section (m^2),
adjustable _gas_mass_amu        = 28.0       -- Mass of background gas particle
adjustable _mark_collisions     = 0          -- Mark collisions (1=yes,0=no).
adjustable pe_update_each_usec  = 0.05       -- PE display update period (in usec)

adjustable _pressure_pa         = 1.0*13.28 -- Pressure (in Pa)
adjustable _freqency_hz         = 0.85E6        -- RF frequency of funnel (in Hz)
adjustable phase_angle_deg      = 0.0        -- entry phase angle of ion (deg)                                             -- Note: 1 Torr = 133.28 Pa.
                                             --   [OVERRIDE HS1]


--adjustable _RF_amplitude        = 100         -- RF peak-to-ground voltage (in V)
--adjustable _DC_offset_1         = 100.0      -- DC offset of electrode 1 (in V)
--adjustable _DC_offset_99        = 0       -- DC offset of electrode 16 (in V)
adjustable _DC_offset_100       = 0       -- DC offset of electrode 17 (in V),
adjustable _DC_offset_101       = 0       -- DC offset of electrode 17 (in V),
                                             --   DC only electrode


function test(dx,dy)

  -- convert GEM file to PA# file.
  _G.dx = dx  -- pass variable to GEM file.
  _G.dy = dy


  local inst = simion.wb.instances[1]
  local pa = simion.open_gem('funnel3.gem'):to_pa()
      -- TODO: this function not yet documented
  pa:save('funnel3.pa#')
  pa:close()

  -- reload in workbench
  inst.pa:load('funnel3.pa#')

  -- refine PA# file.
  inst.pa:refine()

    --inst.pa:crop( unpack(crop_range) )
  inst:_debug_update_size()
  simion.redraw_screen()


  run()

  --return kk

  -- Fly ions and collect results

  --print("RESULT: dx=" .. dx .. ", ion_py_gu=" .. result_y)

  --return kk

end


-- Population of genes.
local population = {}

local function print_chromosome(i, name)
  print(name or 'chromo', i, population[i].metric, unpack(population[i]))
end

local function print_population()
  for i=1,population_size do
    print_chromosome(i)
  end
end


local DC_voltage
local RF_voltage
local d_mm
local r_mm


function segment.flym()

  sim_trajectory_image_control = 1 -- don't keep trajectories


  --os.execute("mkdir output")

  --os.remove("output/results.csv")

  --local results_file = assert(io.open("output/results.csv", "w")) -- write mode
  --results_file:write("dd, dr\n")
  --local html = Html("output/results.html")

  --sim_trajectory_image_control = 1 -- don't keep trajectories

  -- Runs genene at given index.
  local function run_it(i)

    DC_voltage, RF_voltage, d_mm, r_mm = unpack(population[i])

	test(d_mm,r_mm)

	metric = kk

	--print(DC_voltage)
	--print(RF_voltage)
	--print(d_mm)
	--print(r_mm)

	--simion.printer.type = 'png'  -- 'bmp', 'png', 'jpg'
    --simion.printer.filename = 'output/result_' .. d_mm .. '.png'
    --simion.printer.scale = 1
    --simion.print_screen()
    -- caution: print_screen redraws the screen.  If ion trajectories
    -- are unsaved (i.e. e.g. sim_rerun_flym == 1), they will be lost.

    -- Write data to file.
    --results_file:write(d_mm .. ", " .. dk .. "\n")
    --results_file:flush()  -- immediately output to disk

	--if html then
      --html:add_image('result_' .. d_mm .. '.png')
      --html:add_line('Figure: dx = ' .. d_mm)
    --end

	--results_file:close()
    --if html then html:close() end

  -- Show results.
    --print "DONE!  See output/results.csv."
    --os.execute([[start notepad output\results.csv]])
    --if html then
    --print "See also output/results.html."
    --os.execute([[start output\results.html]]) -- or "firefox"
      -- note: need for two "starts" may be a bug in SIMION (TO REVIEW)
    --end


    population[i].metric = metric
	--print(kk)
  end

  -- Create genes.
  local mins = {DC_min, RF_min, d_min, r_min}
  local maxs = {DC_max, RF_max, d_max, r_max}
  for i=1, population_size do
    population[i] = OPT.random(mins, maxs)
  end

  -- Runs all genes in population.
  for i=1,population_size do
    run_it(i)
  end
  --print_population()

  -- Run all children in population, finding best.
  local best
  for j=1,max_iterations do
    -- Select two chromosomes to eliminate.
    -- local ireplace1, ireplace2 = OPT.select_two_worst(population)
    local ireplace1, ireplace2 = OPT.select_two_roulette(population, 'worst')

    -- Select two chromosomes to cross-over.
    local i1, i2 = OPT.select_two_roulette(population)
    -- print('remove', ireplace1, ireplace2, 'crossover', i1, i2)

    -- Cross-over chromosomes and replace.
    local child1 = OPT.crossover_arithmetic_whole(population[i1], population[i2])
    local child2 = OPT.crossover_arithmetic_whole(population[i1], population[i2])
    --print_chromosome(i1, 'crossover-parent')
    --print_chromosome(i2, 'crossover-parent')
    population[ireplace1] = child1
    population[ireplace2] = child2
    --print_chromosome(ireplace1, 'crossover-child')
    --print_chromosome(ireplace2, 'crossover-child')

    -- Mutate chromosomes.
    if rand() < mutation_probability then
      OPT.mutate_random_cubed_single(population[ireplace1], mins, maxs)
      --print_chromosome(ireplace1, 'mutate-child   ')
      --not used:
      OPT.mutate_random_cubed_single(population[ireplace2], mins, maxs)
      --print_chromosome(ireplace2, 'mutate-child   ')
    end

    -- Run new chromosomes
    run_it(ireplace1)
    run_it(ireplace2)

    --print_population()

    -- Find any best gene.
    local ibest = OPT.select_best(population)
    if not best or population[ibest].metric < best.metric then
      best = population[ibest]
    end
    if best.metric < metric_goal then
      print('attained tuning goal', metric_goal)
      break
    end
  end

  -- Do one more run, keeping trajectories.
  population[1] = best
  run_it(1)
  print_chromosome(1, 'best')
  print('num runs', ion_run)
  --sim_retain_changed_potentials = 1  -- keep tuned electrode voltages
end


function segment.tstep_adjust()
   -- Keep time step size below some fraction of the RF period.
   -- See "Time Step Size" comments.
   ion_time_step = min(ion_time_step, 0.1*1E+6/_freqency_hz)  -- X usec
end



-- internal variables
local omega                 -- frequency in radians / usec
local theta                 -- phase offset in radians
local last_pe_update = 0.0  -- last potential energy surface update time (usec)


function segment.initialize_run()
  -- Reset the counter before each rerun (only needed if Rerun is enabled).

  --sim_rerun_flym = 0


  --sim_trajectory_image_control = 1 -- keep trajectories (when rerun 0)

  metric = 0

  num_hits = 0

  --num_particles = ion_number

end

function segment.initialize()
  -- Infer total number of particles flown.  [*1]
  -- Optionally store data on this particle's starting conditions.  [*2]
end



local theta = phase_angle_deg * (3.141592 / 180)
local omega = _freqency_hz * 6.28318E-6

function segment.fast_adjust()
    -- NOTE: This segment is the only code that differs from funnel2.lua.

    -- Initialize constants once.
    --if not theta then

    --end

    -- Apply RF+DC to each electrode (see README file for explanation).
    adj_elect01 = RF_voltage * sin(ion_time_of_flight * omega + theta)
    adj_elect02 = DC_voltage
    adj_elect03 = _DC_offset_100 - DC_voltage
    adj_elect04 = _DC_offset_101

end


-- This trick first runs the other_actions segment defined previously
-- by the HS1 collision model and then runs our own code.


local previous_other_actions = segment.other_actions  -- copy previously defined segment.
function segment.other_actions()
    -- Run previously defined segment.
    previous_other_actions()
    -- Now run our own code...

    -- Update PE surface display.
    if abs(ion_time_of_flight - last_pe_update) >= pe_update_each_usec then
        last_pe_update = ion_time_of_flight
        sim_update_pe_surface = 1    -- Request a PE surface display update.
    end

	if ion_time_of_flight > 1200  then

	ion_splat=1

	end

	if ion_px_mm >= (100*(d_mm+0.5)+0.45) then

	  if math.sqrt(ion_py_mm^2+ion_pz_mm^2) <= 1 then

	  num_hits = num_hits + 1

	  end

	  ion_splat=1

	end

end

-- called on each particle termination inside a PA instance...

-- called on end of each run...
function segment.terminate_run()
  -- Print summary data at end of run.
  --sim_rerun_flym = 1 -- clears trajectories on rerun

  kk = (sim_ions_count-num_hits)/sim_ions_count
  --print('num_particles=',  num_particles)
  --print('num_hits=',       num_hits)
  --print('efficiency (%)=', transmission)
end


