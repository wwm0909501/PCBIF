--[[
 Genetic algorithm (GA) search routines.
 WARNING: very preliminary.
 
 For an intro to genetic algorithms, see
 https://www.tutorialspoint.com/genetic_algorithms/genetic_algorithms_quick_guide.htm
 http://www.myreaders.info/09_Genetic_Algorithms.pdf

 2016-12-06, D.Manura
 (c) 2016 Scientific Instrument Services, Inc. (Licensed SIMION 8.1)
--]]


local M = {}

-- Gets randomized chromosome.
function M.random(mins, maxs)
  local vector = {}
  for i=1,#mins do
    vector[i] = mins[i] + rand() * (maxs[i] - mins[i])
  end
  return vector
end

-- Selects a chromosome from given list of probabilities.
function M.select_probabilistically(population, probabilities)
  local r = rand()
  local sum = 0
  for i=1,#probabilities do
    sum = sum + probabilities[i]
    if r <= sum then
      return i
    end
  end
  return #population
end

-- Cross-overs two real-valued chromosomes by whole arithmetic method.
function M.crossover_arithmetic_whole(a, b)
  local v = {}
  local f = rand()
  for i=1,#a do
    v[i] = f * a[i] + (1 - f) * b[i]
  end
  return v
end

-- Mutates single gene, uniformly randomly.
function M.mutate_random_single(a, mins, maxs)
  local i = math.floor(rand() * #a) + 1
  a[i] = mins[i] + rand() * (maxs[i] - mins[i])
end

-- Mutates single gene, more likely small changes from original value.
function M.mutate_random_cubed_single(a, mins, maxs)
  local i = math.floor(rand() * #a) + 1
  if rand() > 0.5 then  -- increase
    a[i] = a[i] + rand()^3 * (maxs[i] - a[i])
  else  -- decrease
    a[i] = a[i] - rand()^3 * (a[i] - mins[i])
  end
end

-- Gets probabilities of chromosomes, best most likely.
function M.compute_probabilities_best(population)
  local probabilities = {}
  local worst = population[M.select_worst(population)].metric
  local sum = 0
  for i=1,#population do
    probabilities[i] = worst - population[i].metric
    sum = sum + probabilities[i]
  end
  for i=1,#population do
    probabilities[i] = sum == 0 and 1/#population or probabilities[i] / sum
  end
  return probabilities
end

-- Gets probabilities of chromosomes, worst most likely.
function M.compute_probabilities_worst(population)
  local probabilities = {}
  local best = population[M.select_best(population)].metric
  local sum = 0
  for i=1,#population do
    probabilities[i] = population[i].metric - best
    sum = sum + probabilities[i]
  end
  for i=1,#population do
    probabilities[i] = sum == 0 and 1/#population or probabilities[i] / sum
  end
  return probabilities
end

-- Roulette wheel selection of two chromosomes.
-- which is either 'best' or 'worst' chromomes to favor selecting.
function M.select_two_roulette(population, which)
  which = which or 'best'
  local CP = which == 'best' and
    M.compute_probabilities_best or
    M.compute_probabilities_worst
  local probabilities = CP(population)
  local iselect = M.select_probabilistically(population, probabilities)
  --for i=1,#population do print('p', population[i].metric, probabilities[i]) end

  local population2 = {}
  for i=1,#population do
    if i ~= iselect then
      table.insert(population2, population[i])
    end
  end
  
  -- Select another from remaining.
  local probabilities2 = CP(population2)
  local iselect2b = M.select_probabilistically(population2, probabilities2)
  local iselect2 = iselect2b >= iselect and iselect2b + 1 or iselect2b
                   -- index in probability array
  return iselect, iselect2
end

-- Selects worst chromosome in population.
function M.select_worst(population)
  local iworst = 1
  for i=2,#population do
    if population[i].metric > population[iworst].metric then
      iworst = i
    end
  end
  return iworst
end

-- Selects best chromosome in population.
function M.select_best(population)
  local ibest = 1
  for i=2,#population do
    if population[i].metric < population[ibest].metric then
      ibest = i
    end
  end
  return ibest
end

-- Selects two worst chromosomes in population.
function M.select_two_worst(population)
  local iworst = M.select_worst(population)
  local isecondworst = iworst == 1 and 2 or 1
  for i=1,#population do
    if i ~= iworst and population[i].metric > population[isecondworst].metric then
      isecondworst = i
    end
  end
  return iworst, isecondworst
end

return M
